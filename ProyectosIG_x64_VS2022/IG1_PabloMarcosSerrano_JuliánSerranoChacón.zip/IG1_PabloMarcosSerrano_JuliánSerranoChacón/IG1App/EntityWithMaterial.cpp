#include "EntityWithMaterial.h"
